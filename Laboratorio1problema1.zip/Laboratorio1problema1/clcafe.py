from heapq import merge

import clcafe


class Cafe:
    def __init__(self, nombre, temperatura, categoria, complejidad, con_alcohol, precio):
        self._nombre = nombre
        self._temperatura = temperatura
        self._categoria = categoria
        self._complejidad = complejidad
        self._con_alcohol = con_alcohol
        self.precio= precio



    # Métodos get
    def get_nombre(self):
        return self._nombre

    def get_temperatura(self):
        return self._temperatura

    def get_categoria(self):
        return self._categoria

    def get_complejidad(self):
        return self._complejidad

    def get_con_alcohol(self):
        return self._con_alcohol

    def get_precio(self):
        return self.precio

    def get_ingredientes(self):
        return self._ingredientes


    # Métodos set
    def set_nombre(self, nombre):
        self._nombre = nombre

    def set_temperatura(self, temperatura):
        self._temperatura = temperatura

    def set_categoria(self, categoria):
        self._categoria = categoria

    def set_complejidad(self, complejidad):
        self._complejidad = complejidad

    def set_con_alcohol(self, con_alcohol):
        self._con_alcohol = con_alcohol

    def set_precio(self, precio):
        self.precio = precio






def agregar_cafe(vector_cafes):
    nombre = input("Ingrese el nombre del café: ")
    temperatura = input("Ingrese la temperatura del café (caliente/frío): ")
    categoria = input("Ingrese la categoría del café (bebida/postre): ")
    complejidad = input("Ingrese la complejidad del café (simple/compuesto): ")
    con_alcohol = input("¿Contiene alcohol? (Sí/No): ").lower()
    precio= float(input("Ingrese el precio del café: "))
    nuevo_cafe = Cafe(nombre, temperatura, categoria, complejidad, con_alcohol,precio)
    vector_cafes.append(nuevo_cafe)
    print(f"\n¡Se ha agregado el café '{nombre}' al vector!")




def imprimirTodo(vector_cafes):
    for ing in vector_cafes

def menu():
    vector_cafes = []

    opc = int(input("Ingrese una opción\n1. Ver menú\n2. Agregar café\n3. Borrar café\n4. Realizar compra\n"))

    if opc == 1:
        #
        pass  #

    elif opc == 2:
        agregar_cafe(vector_cafes)





# Llamar a la función menu
menu()

